// Question No:02
// Create Result-Sheet Program Using Student Class having data member: roll,name,sub1,sub2 , Sub3 ,total display result-sheet in following format ??
#include <iostream>
#include <string>
using namespace std;

class Student {

}

private:
    int roll;           // Roll number
    string name;        // Student's name
    float sub1, sub2, sub3;  // Marks in three subjects
    float total;        // Total marks

public:
    // Function to input student details
    void inputDetails() {
        cout << "Enter Roll Number: ";
        cin >> roll;
        cin.ignore();  // To clear the buffer after entering the roll number
        cout << "Enter Name: ";
        getline(cin, name);
        cout << "Enter marks for Subject 1: ";
        cin >> sub1;
        cout << "Enter marks for Subject 2: ";
        cin >> sub2;
        cout << "Enter marks for Subject 3: ";
        cin >> sub3;
    }

    // Function to calculate the total marks
    void calculateTotal() {
        total = sub1 + sub2 + sub3;
    }

    // Function to display result
    void displayResult() {
        cout << "--------------------------------------------" << endl;
        cout << "Roll No. | Name              | Subject 1 | Subject 2 | Subject 3 | Total" << endl;
        cout << "--------------------------------------------" << endl;
        cout << roll << "    | " << name << "     | " 
             << sub1 << "     | " << sub2 << "     | " << sub3 << "     | " << total << endl;
        cout << "----------------------------------------


